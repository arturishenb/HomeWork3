import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        int[] nums = {8, -2, -4, 2, 3, 6};
        System.out.println(nums[3]);
        nums[2] = 5;
        System.out.println(nums);
        System.out.println(Arrays.toString(nums));

        double digits[] = new double[4];
        System.out.println(Arrays.toString(digits));
        digits[3] = 11.3;
        System.out.println(Arrays.toString(digits));
    }
}